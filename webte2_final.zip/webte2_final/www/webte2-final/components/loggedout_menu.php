<header class="p-3 text-bg-dark">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                <li><a href="index.php" class="nav-link px-2 text-white">Semestrálne zadanie</a></li>
            </ul>

            <div class="text-end">
                <a href="index.php" class="btn btn-outline-light me-2">Prihlásiť sa</a>
                <a href="register.php" class="btn btn-warning">Registrovať sa</a>
            </div>
        </div>
    </div>
</header>